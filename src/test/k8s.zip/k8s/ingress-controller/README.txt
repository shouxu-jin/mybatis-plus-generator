wget https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.10.0/deploy/static/provider/cloud/deploy.yaml
修改为nodeport
  ports:
  - appProtocol: http
    name: http
    port: 80
    protocol: TCP
    targetPort: 80
    nodePort: 31075
  - appProtocol: https
    name: https
    port: 443
    protocol: TCP
    targetPort: 443
    nodePort: 32457

kubectl apply -f deploy.yaml