wget https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml

--修改recommended.yaml
kind: Service
apiVersion: v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
spec:
  ports:
    - port: 443
      targetPort: 8443
      nodePort: 32001
  selector:
    k8s-app: kubernetes-dashboard
  type: NodePort
-- 添加token-ttl
          args:
            - --auto-generate-certificates
            - --namespace=kubernetes-dashboard
            - --token-ttl=0

kubectl apply -f recommended.yaml
kubectl create -f admin-user.yaml
kubectl create -f admin-user-role-binding.yaml
kubectl -n kubernetes-dashboard create token admin-user --duration=40000000000s
保存token